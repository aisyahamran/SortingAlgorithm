package Qs;

import java.io.FileWriter;
import java.io.IOException;

public class WriteFile {
    String FileName;

    WriteFile(String FileName) {
        this.FileName = FileName;
    }

    public void writeFile(String FileName, String[] arr) {

        try {

            FileWriter writer = new FileWriter(FileName, true);

            for (int i = 0; i < arr.length; i++) {
                writer.write(arr[i] + "\n");
            }
            writer.close();

        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}

