package Qs;

public class Main extends Sort {
    public static void main(String[] args) throws Exception
    {
        //assign file name
        ReadFile readFile = new ReadFile();
        String bstFile = "BestList.txt";
        String avgFile = "AvgList.txt";
        String wrsFile = "WrsList.txt";

        //Read file bestFile
        String[] best = readFile.readFile(bstFile);
        System.out.println("Best case Bubble Sort \n");
        //call bubble sort at different length at increment 200
        for (int i = 0; i < 1000; i+=200){
            bubbleSort(best,i);
        }
        //Read file bestFile
        String[] besti = readFile.readFile(bstFile);
        System.out.println("\nBest case Insrtion Sort \n");
        //call insertion sort at different length at increment 200
        for (int i = 0; i < 1000; i+=200){
            InsertionSort(besti,i);
        }
        //Read file bestFile
        String[] bestq = readFile.readFile(bstFile);
        //call quick sort at different length at increment 200
        System.out.println("\nBest case Quick Sort \n");
        for (int i = 0; i < 1000; i+=200){
            sort(bestq,i);
        }
        //Read file Average File
        String[] avg =  readFile.readFile(avgFile);
        //call bubble sort at different length at increment 200
        System.out.println("\nAverage case Bubble Sort \n");
        for (int i = 0; i < 1000; i+=200){
            bubbleSort(avg,i);
        }
        //Read file Average File
        String[] avgi =  readFile.readFile(avgFile);
        //call insertion sort at different length at increment 200
        System.out.println("\nAverage case Insertion Sort \n");
        for (int i = 0; i < 1000; i+=200){
            InsertionSort(avgi,i);
        }
        //Read file Average File
        String[] avgq =  readFile.readFile(avgFile);
        //call quick sort at different length at increment 200
        System.out.println("\nAverage case Quick Sort \n");
        for (int i = 0; i < 1000; i+=200){
            sort(avgq,i);
        }
        //Read file worst File
        String[] worst =  readFile.readFile(wrsFile);
        System.out.println("\nWorst case Bubble Sort\n");
        //call bubble sort at different length at increment 200
        for (int i = 0; i < 1000; i+=200){
            bubbleSort(worst,i);
        }
        //Read file worst File
        String[] worsti =  readFile.readFile(wrsFile);
        System.out.println("\nWorst case Insertion Sort\n");
        //call insertion sort at different length at increment 200
        for (int i = 0; i < 1000; i+=200){
            InsertionSort(worsti,i);
        }
        //Read file worst File
        String[] worstq =  readFile.readFile(wrsFile);
        //call quick sort at different length at increment 200
        System.out.println("\nWorst case Quick Sort\n");
        for (int i = 0; i < 1000; i+=200){
            sort(worstq,i);
        }
    }
}
