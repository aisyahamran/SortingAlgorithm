package Qs;

public class Sort {

    String[] names;
    static long count = 0;
    public static void bubbleSort(String[] arr, int size) {

        count = 0;
        String temp;
        count++;
        // loop to access array element
        for (int i= 0; i < size; i++) {
            count += 2;
            // loop to compare array element
            for (int j = i + 1; j < size; j++){
                count += 4;
                count += 4;
                // condition to compare elements whether current
                //array element in j is smaller or bigger than element in array  i
                if (arr[j].compareTo(arr[i]) < 0) {
                    //swapping when element in array not in intended order
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                    count += 6;
                }
            }
        }
        //print premitive
        System.out.println("Size: " + size + " Number of counters: " + count);
    }

    public static void InsertionSort(String[] arr, int size) {

        count++;
        for (int i = 1; i < size; i++) {
            String temp = arr[i];
            int j = i - 1;
            count+= 7;

            if (temp != null) { // condition where temp in not null
                // compare temp with element on left that is small until it is found
                while (j >= 0 && arr[j].compareTo(temp) > 0) {
                    arr[j + 1] = arr[j];
                    j--;
                    count+= 9;
                }
                // Place temp at after the element just smaller than it
                arr[j + 1] = temp;
                count+= 3;
            }
        }
        //print premitive
        System.out.println("Size: " + size + " Number of counters: " + count);
    }

    public static void sort(String array[], int size) {
        if (array == null || size == 0) {
            return;
        }
        String[] names = array;
        long x = quickSort(names, 0, size - 1, count);
        System.out.println("Size: " + size + " Number of counters: " + x);
    }
    /* This function takes last element as pivot, places the pivot
        element at its correct position in sorted array,
     *  and places all smaller (smaller than pivot)
       to left of pivot and all greater elements to right of pivot */
    public static long quickSort(String[] names, int lowerIndex, int higherIndex, long count) {
        int i = lowerIndex;
        int j = higherIndex;

        // The pivot point of the sort method is arbitrarily set to the element in the array
        String pivot = names[lowerIndex + (higherIndex - lowerIndex) / 2];
        count += 5;
        // only scan between the two indexes, until they meet
        while (i <= j) {
            count += 1;
            /*
            from the left, if the current element is lexicographically less than the (original)
            first element in the String array, move on. Stop advancing the counter when we reach
            the right or an element that is lexicographically greater than the pivot String.
            */
            while (names[i].compareToIgnoreCase(pivot) < 0) {
                i++;
                count += 4;
            }
            /*from the right, if the current element is lexicographically greater than the (original)
              first element in the String array, move on. Stop advancing the counter when we reach
              the left or an element that is lexicographically less than the pivot String. */
            while (names[j].compareToIgnoreCase(pivot) > 0) {
                j--;
                count += 4;
            }

            count += 1;
            if (i <= j) {
                exchangeNames(names, i, j, count);
                i++;
                j--;
                count += 2;
            }
        }
        //call quickSort recursively
        count += 1;
        if (lowerIndex < j) {
            quickSort(names, lowerIndex, j, count);
        }
        count += 1;
        if (i < higherIndex) {
            quickSort(names, i, higherIndex, count);
        }

        return count;
    }
    // A utility function to exchange two elements
    public static long exchangeNames(String[] names, int i, int j, long count) {
        String temp = names[i];
        names[i] = names[j];
        names[j] = temp;
        return count += 6;
    }
}


