package Qs;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadFile {
    String FileName;

    public String[] readFile(String FileName) throws IOException {

        List<String> words = new ArrayList<String>();
        BufferedReader reader = new BufferedReader(new FileReader(FileName));
        String line = reader.readLine();
        while(line != null){
            words.add(line);
            line = reader.readLine();
        }
        reader.close();

        String[] str = words.toArray(new String[0]);
        return str;
    }
}
